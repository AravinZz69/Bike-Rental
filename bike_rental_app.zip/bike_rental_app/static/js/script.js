// ========================================
// Bike Rental Prediction - JavaScript
// ========================================

// Update hour display as slider moves
function updateHourDisplay(hour) {
    hour = parseInt(hour);
    const displayHour = hour % 12 || 12;
    const period = hour >= 12 ? 'PM' : 'AM';
    document.getElementById('hourDisplay').textContent = `${displayHour}:00 ${period}`;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Set initial hour display
    updateHourDisplay(document.getElementById('hr').value);
    
    // Form submission handler
    const form = document.getElementById('predictionForm');
    form.addEventListener('submit', handleFormSubmit);
    
    // Reset button handler
    form.addEventListener('reset', function() {
        setTimeout(() => {
            hideResults();
            updateHourDisplay(8);
        }, 10);
    });
});

// Handle form submission
async function handleFormSubmit(event) {
    event.preventDefault();
    
    // Get form data
    const formData = new FormData(event.target);
    const data = {
        registered: parseInt(formData.get('registered')),
        season: parseInt(formData.get('season')),
        mnth: parseInt(formData.get('mnth')),
        hr: parseInt(formData.get('hr')),
        holiday: parseInt(formData.get('holiday')),
        weekday: parseInt(formData.get('weekday')),
        workingday: parseInt(formData.get('workingday')),
        weathersit: parseInt(formData.get('weathersit'))
    };
    
    // Show loading state
    showLoading();
    
    try {
        // Make API request
        const response = await fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            displayResults(result.prediction, data);
        } else {
            displayError(result.error || 'An error occurred during prediction');
        }
    } catch (error) {
        displayError('Failed to connect to the server. Please try again.');
        console.error('Error:', error);
    }
}

// Show loading spinner
function showLoading() {
    document.getElementById('initialState').classList.add('d-none');
    document.getElementById('resultsContainer').classList.add('d-none');
    document.getElementById('errorContainer').classList.add('d-none');
    document.getElementById('loadingSpinner').classList.remove('d-none');
}

// Hide results and show initial state
function hideResults() {
    document.getElementById('initialState').classList.remove('d-none');
    document.getElementById('resultsContainer').classList.add('d-none');
    document.getElementById('errorContainer').classList.add('d-none');
    document.getElementById('loadingSpinner').classList.add('d-none');
}

// Display prediction results
function displayResults(prediction, inputData) {
    // Hide loading and error
    document.getElementById('loadingSpinner').classList.add('d-none');
    document.getElementById('errorContainer').classList.add('d-none');
    document.getElementById('initialState').classList.add('d-none');
    
    // Show results
    const resultsContainer = document.getElementById('resultsContainer');
    resultsContainer.classList.remove('d-none');
    resultsContainer.classList.add('fade-in');
    
    // Update prediction value
    document.getElementById('predictionValue').textContent = prediction;
    
    // Update demand indicator
    updateDemandIndicator(prediction);
    
    // Update input summary
    updateInputSummary(inputData);
    
    // Update recommendation
    updateRecommendation(prediction, inputData);
    
    // Scroll to results
    resultsContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Update demand level indicator
function updateDemandIndicator(prediction) {
    const progress = document.getElementById('demandProgress');
    const label = document.getElementById('demandLabel');
    
    // Calculate percentage (assuming max demand of 1000)
    const percentage = Math.min((prediction / 1000) * 100, 100);
    
    // Determine demand level
    let demandLevel, demandClass, demandText;
    
    if (prediction < 200) {
        demandLevel = 'Low';
        demandClass = 'bg-success demand-low';
        demandText = 'Low Demand';
    } else if (prediction < 500) {
        demandLevel = 'Medium';
        demandClass = 'bg-warning demand-medium';
        demandText = 'Medium Demand';
    } else {
        demandLevel = 'High';
        demandClass = 'bg-danger demand-high';
        demandText = 'High Demand';
    }
    
    // Update progress bar
    progress.style.width = percentage + '%';
    progress.setAttribute('aria-valuenow', percentage);
    progress.className = 'progress-bar ' + demandClass;
    label.textContent = demandText;
}

// Update input summary
function updateInputSummary(data) {
    const seasonNames = ['', 'Spring', 'Summer', 'Fall', 'Winter'];
    const monthNames = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const weekdayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const weatherNames = ['', 'Clear/Partly Cloudy', 'Mist/Cloudy', 'Light Rain/Snow', 'Heavy Rain/Snow'];
    
    const hour = parseInt(data.hr);
    const displayHour = hour % 12 || 12;
    const period = hour >= 12 ? 'PM' : 'AM';
    
    const summary = `
        <div class="row">
            <div class="col-6">
                <strong>Time:</strong> ${displayHour}:00 ${period}<br>
                <strong>Day:</strong> ${weekdayNames[data.weekday]}<br>
                <strong>Month:</strong> ${monthNames[data.mnth]}<br>
                <strong>Season:</strong> ${seasonNames[data.season]}
            </div>
            <div class="col-6">
                <strong>Weather:</strong> ${weatherNames[data.weathersit]}<br>
                <strong>Holiday:</strong> ${data.holiday ? 'Yes' : 'No'}<br>
                <strong>Working Day:</strong> ${data.workingday ? 'Yes' : 'No'}<br>
                <strong>Registered:</strong> ${data.registered} users
            </div>
        </div>
    `;
    
    document.getElementById('inputSummary').innerHTML = summary;
}

// Generate recommendation based on prediction
function updateRecommendation(prediction, data) {
    let recommendation = '';
    
    if (prediction < 100) {
        recommendation = '🔵 Very low demand expected. Consider reducing available bikes in this area or redirecting resources to higher-demand locations.';
    } else if (prediction < 200) {
        recommendation = '🟢 Low demand expected. Normal operations should be sufficient. Good time for maintenance activities.';
    } else if (prediction < 400) {
        recommendation = '🟡 Moderate demand expected. Ensure adequate bike availability. Monitor popular stations closely.';
    } else if (prediction < 600) {
        recommendation = '🟠 High demand expected. Increase bike availability and consider deploying additional bikes to meet demand.';
    } else {
        recommendation = '🔴 Very high demand expected! Deploy maximum available bikes. Consider surge pricing and ensure rapid bike redistribution.';
    }
    
    // Add time-based insights
    const hour = parseInt(data.hr);
    if (hour >= 7 && hour <= 9) {
        recommendation += ' Peak morning commute hours - expect higher demand near transit hubs.';
    } else if (hour >= 17 && hour <= 19) {
        recommendation += ' Peak evening commute hours - prepare for rush hour demand.';
    } else if (hour >= 22 || hour <= 5) {
        recommendation += ' Late night/early morning hours - minimal demand expected.';
    }
    
    // Add weather-based insights
    if (data.weathersit >= 3) {
        recommendation += ' ⚠️ Poor weather conditions may reduce actual demand below predictions.';
    }
    
    document.getElementById('recommendation').textContent = recommendation;
}

// Display error message
function displayError(message) {
    document.getElementById('loadingSpinner').classList.add('d-none');
    document.getElementById('resultsContainer').classList.add('d-none');
    document.getElementById('initialState').classList.add('d-none');
    
    const errorContainer = document.getElementById('errorContainer');
    errorContainer.classList.remove('d-none');
    errorContainer.classList.add('fade-in');
    
    document.getElementById('errorMessage').textContent = message;
}

// Utility function to format numbers
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Add input validation
document.addEventListener('DOMContentLoaded', function() {
    const registeredInput = document.getElementById('registered');
    
    registeredInput.addEventListener('input', function() {
        if (this.value < 0) this.value = 0;
        if (this.value > 1000) this.value = 1000;
    });
});

// Add keyboard shortcuts
document.addEventListener('keydown', function(event) {
    // Ctrl/Cmd + Enter to submit form
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
        document.getElementById('predictionForm').dispatchEvent(new Event('submit'));
    }
    
    // Escape to reset form
    if (event.key === 'Escape') {
        document.getElementById('predictionForm').reset();
        hideResults();
    }
});

// Console welcome message
console.log('%c🚴 Bike Rental Prediction System', 'color: #667eea; font-size: 20px; font-weight: bold;');
console.log('%cPowered by Machine Learning (AdaBoost)', 'color: #764ba2; font-size: 14px;');
console.log('%cKeyboard Shortcuts:\n- Ctrl/Cmd + Enter: Submit form\n- Escape: Reset form', 'color: #666; font-size: 12px;');
